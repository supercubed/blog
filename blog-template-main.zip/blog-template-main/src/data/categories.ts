// List of categories for blog posts
export const CATEGORIES = [
	'Category 1',
	'Category 2',
	'Category 3',
	'Category 4',
	'Category 5'
] as const
